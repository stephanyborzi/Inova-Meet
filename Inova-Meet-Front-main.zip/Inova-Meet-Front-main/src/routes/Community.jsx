import { CommunityPage } from "@/section/community";
import React from "react";

const Community = () => {
  return <CommunityPage />;
};

export default Community;
