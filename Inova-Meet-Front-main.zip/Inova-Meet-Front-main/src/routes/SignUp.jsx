import { SignUpPage } from "@/section/sign-up";
import React from "react";

const SignUp = () => {
  return <SignUpPage />;
};

export default SignUp;
