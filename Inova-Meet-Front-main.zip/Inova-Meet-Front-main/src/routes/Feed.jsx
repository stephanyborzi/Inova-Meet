import { HomeFeedPage } from "@/section/home-feed";
import React from "react";

const Feed = () => {
  return <HomeFeedPage />;
};

export default Feed;
