import { ProfilePage } from "@/section/profiles";
import React from "react";

const Profile = () => {
  return <ProfilePage />;
};

export default Profile;
