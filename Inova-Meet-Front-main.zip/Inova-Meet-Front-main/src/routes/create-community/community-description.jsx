
import { CreateCommunityDescription } from "@/section/create-community/community-description-page";
import React from "react";

const CommunityDescription = () => {
  return <CreateCommunityDescription />;
};

export default CommunityDescription;
