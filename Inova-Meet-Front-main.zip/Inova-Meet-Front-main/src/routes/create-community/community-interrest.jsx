
import { CreateCommunityInterest } from "@/section/create-community/community-interest-page";
import React from "react";

const CommunityInterest = () => {
  return <CreateCommunityInterest />;
};

export default CommunityInterest;
