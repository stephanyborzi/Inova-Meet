import { CreateCommunityReview } from "@/section/create-community/community-review-page";
import React from "react";

const CommunityReview = () => {
  return <CreateCommunityReview />;
};

export default CommunityReview;
