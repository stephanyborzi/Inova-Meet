
import { CreateCommunityName } from "@/section/create-community/community-name-page";
import React from "react";

const CommunityName = () => {
  return <CreateCommunityName />;
};

export default CommunityName;
