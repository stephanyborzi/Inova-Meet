import { CreateCommunityAvatar } from "@/section/create-community/community-avatar-page";
import React from "react";

const CommunityAvatar = () => {
  return <CreateCommunityAvatar />;
};

export default CommunityAvatar;
