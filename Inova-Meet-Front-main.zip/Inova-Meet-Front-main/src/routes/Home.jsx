import { LandingHome } from "@/section/landing-home";
import React from "react";

const Home = () => {
  return <LandingHome />;
};

export default Home;
