import { LoginPage } from "@/section/Login";
import React from "react";

const Login = () => {
  return <LoginPage />;
};

export default Login;
