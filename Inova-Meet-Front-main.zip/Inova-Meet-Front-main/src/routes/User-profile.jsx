import { UserProfilePage } from "@/section/user-profile";
import React from "react";

const UserProfile = () => {
  return <UserProfilePage />;
};

export default UserProfile;
